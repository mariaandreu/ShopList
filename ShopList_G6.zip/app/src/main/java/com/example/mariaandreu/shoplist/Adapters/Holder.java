package com.example.mariaandreu.shoplist.Adapters;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.example.mariaandreu.shoplist.R;
import com.example.mariaandreu.shoplist.TestInterface;

import java.util.List;

/**
 * Created by mariaandreu on 20/12/17.
 */

public class Holder extends RecyclerView.ViewHolder {

    // Hinchar los TextView - Crearlos y Referenciarlos

    TextView textViewName;
    TextView textViewCount;
    CheckBox checkBox;
    List<Integer> posiciones;

    public Holder(View itemView, final TestInterface testInterface) { // recibimos la vista y referenciamos los textView al layout
        super(itemView);
        textViewCount = itemView.findViewById(R.id.textView);
        textViewName = itemView.findViewById(R.id.textView2);
        checkBox = itemView.findViewById(R.id.checkbox);


    }

    public TextView getTextViewName() {
        return textViewName;
    }

    public void setTextViewName(TextView textViewName) {
        this.textViewName = textViewName;
    }

    public TextView getTextViewCount() {
        return textViewCount;
    }

    public void setTextViewCount(TextView textViewCount) {
        this.textViewCount = textViewCount;
    }

    public CheckBox getCheckBox() {
        return checkBox;
    }

    public void setCheckBox(CheckBox checkBox) {
        this.checkBox = checkBox;
    }





}
