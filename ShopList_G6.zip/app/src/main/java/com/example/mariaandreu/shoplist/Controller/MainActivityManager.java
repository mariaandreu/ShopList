package com.example.mariaandreu.shoplist.Controller;

import android.content.Intent;

import com.example.mariaandreu.shoplist.Model.ItemList;

import java.util.ArrayList;

/**
 * Created by mariaandreu on 20/12/17.
 */

public class MainActivityManager {

    // Almacena los datos para poder crear el adaptador (tiene el contenido)
    private ArrayList<ItemList> itemLists;

    public MainActivityManager(){ // Contructor vacio porque el guarda los datos, no la actividad
        this.itemLists = new ArrayList<>();
        // Esto se llama mog (creado a mano) - Lo normal es hacerlo con BBDD
        itemLists.add(new ItemList("Arroz", 2)); // instancia y nombre de los items
        itemLists.add(new ItemList("Pan", 1)); // instancia y nombre de los items
        itemLists.add(new ItemList("Patata", 2));
    }

    public ArrayList<ItemList> getItemLists() {
        return itemLists;
    }

    public void setItemLists(ArrayList<ItemList> itemLists) {
        this.itemLists = itemLists;
    }
}
