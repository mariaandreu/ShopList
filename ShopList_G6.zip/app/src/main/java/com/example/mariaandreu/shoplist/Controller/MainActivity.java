package com.example.mariaandreu.shoplist.Controller;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import com.example.mariaandreu.shoplist.Adapters.Adapter;
import com.example.mariaandreu.shoplist.Adapters.Holder;
import com.example.mariaandreu.shoplist.Model.ItemList;
import com.example.mariaandreu.shoplist.R;
import com.example.mariaandreu.shoplist.TestInterface;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private MainActivityManager manager; // se encarga de contener una array de items y de añadirles valores
    private RecyclerView recyclerView;
    private TextView textViewN, textViewU;
    private String items;
    private Integer unidades;
    private List<Integer> numerosChecked;
    // Implementar lista Clear con una lista de Strings para poder sustituirla cuando le demos al boton del onclick
    private EditText editTextN, editTextU;
    private Button buttonA, buttonC;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager = new MainActivityManager(); // instanciamos y creamos el manager

        recyclerView = findViewById(R.id.recyclerView);
        buttonA = (Button)findViewById(R.id.buttonAdd);
        textViewN = (TextView)findViewById(R.id.textViewName);
        textViewU = (TextView)findViewById(R.id.textViewUnits);
        editTextN = (EditText)findViewById(R.id.editTextName);
        editTextU = (EditText)findViewById(R.id.editTextUnits);
        buttonC = (Button)findViewById(R.id.buttonClear);

        // final Intent intent = new Intent(this, MainActivityManager.class);
        // final int U1 = intent.getIntExtra("units", 0);
        // final String I1 = intent.getStringExtra("item");

        final Adapter adapter = new Adapter(manager.getItemLists(), this, new TestInterface() {
            @Override
            public void onClicked(int position, boolean status) {
                //      int posiciones = position;
               // numerosChecked.add(position);
                //int posiciones = position;
                if (status == true) {manager.getItemLists().remove(position);};

               // get nombre y unidades que hayamos apretado
            }
        });

        // Cuidado con la inserción de clases
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext())); // puesto verticalmente
        recyclerView.setAdapter(adapter);

        buttonA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                items = editTextN.getText().toString();
                unidades = Integer.parseInt(String.valueOf(editTextU.getText()));
               // intent.putExtra("units", unidades);
               // intent.putExtra("item", items);
                //manager.addItem();
                manager.getItemLists().add(new ItemList(items, unidades));
                Toast.makeText(getApplicationContext(), "s'ha afegit "+items+ " "+unidades +" a la llista", Toast.LENGTH_LONG).show();
                adapter.notifyDataSetChanged();
                editTextN.setText("");
                editTextU.setText("");
            }
        });

        buttonC.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (manager.getItemLists().size() == 0){
                    Toast.makeText(getApplicationContext(),"La lista está vacía!!", Toast.LENGTH_LONG).show();
                }
                else {
                 //   manager.getItemLists().remove(manager.getItemLists().get(position));
                 //   for (int i=0; i<numerosChecked.size();i++){
                //  manager.getItemLists().remove(numerosChecked.indexOf(i)); // tenemos que comprobar si el checkbox está presionado o no
                    // visualizaremos
                   // adapter.notifyDataSetChanged();

                    // solo añadirá esta posición porque no nos coje las posiciones que tocan.
                    Snackbar snackbar = Snackbar
                            .make(recyclerView, "Se ha eliminado el item", Snackbar.LENGTH_LONG)
                            .setAction("Deshacer", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    manager.getItemLists().add(new ItemList("Arroz",2));
                                    adapter.notifyDataSetChanged();
                                    Snackbar snackbar1 = Snackbar.make(recyclerView, "Se ha restaurado el item", Snackbar.LENGTH_SHORT);
                                    snackbar1.show();
                                }
                            });

                    snackbar.show();


                }
            }
        });

    }

}
