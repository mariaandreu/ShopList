package com.example.mariaandreu.shoplist.Adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;

import com.example.mariaandreu.shoplist.Model.ItemList;
import com.example.mariaandreu.shoplist.R;
import com.example.mariaandreu.shoplist.TestInterface;


import junit.framework.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mariaandreu on 20/12/17.
 */

// visualiza elementos en un listado de tipo holder

public class Adapter extends RecyclerView.Adapter<Holder>{

    private ArrayList<ItemList> items;
    private Activity activity; // ahorramos transparencia de datos
    boolean marcado;
    Integer idCheckbox;
    String texto;
    List<Integer> numerosMarcados;
    TestInterface testInterface;

    public Adapter(ArrayList<ItemList> getItems, Activity activity, TestInterface testInterface){ // para recoger un layout - se añaden items y actividad
        this.items = getItems;
        this.activity = activity;
        this.testInterface = testInterface;
    }

    // 1. Inflar layout de tipo holder (encargada de referenciar los items del layout) - Donde recogemos el layout y se crea la vista del Holder

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = activity.getLayoutInflater().inflate(R.layout.holder, parent,false); // inflar el layout de la vista que se va a repetir en cada una de las filas
        Holder holder = new Holder(view, testInterface); // pasamos el layout recogido para poder referenciar los elementos a la vista
        return holder;
    }

    // 2. Poner valores a los textView que contiene el holder en cada celda de la lista y se puede hacer el seteo a los valores de los elementos del Holder
    @Override
    public void onBindViewHolder(final Holder holder, final int position) {
        final ItemList item = items.get(position); // item de la lista en esa posicion
        holder.textViewName.setText(item.getName());
        holder.textViewCount.setText(String.valueOf(item.getCantidad()));
        numerosMarcados = holder.posiciones;


        //in some cases, it will prevent unwanted situations
        //holder.checkBox.setOnCheckedChangeListener(null);

        //if true, your checkbox will be selected, else unselected
       // holder.checkBox.setChecked(items.get(position).isSelected());
      //  holder.checkBox.setTag(position);
        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //numerosMarcados = holder
                // implementación del setOnChangeListener
                //get(holder.getAdapterPosition()).setSelected(isChecked);
                // falta añadir las posiciones que toquen en la lista de posiciones de checkboxes
               // items.get(holder.getAdapterPosition()).setSelected(isChecked);
                notifyDataSetChanged();
            }
        });

        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean status = ((CheckBox)view).isChecked();
                testInterface.onClicked(position,status);
            }
        });

    }

    // 3. Cuantos items se van a representar (+estructura de datos a visualizar) - Lista ItemList
    @Override
    public int getItemCount() {
        return items.size(); //Devuelve el numero de items que hayamos puesto
    }


}
