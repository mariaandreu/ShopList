package com.example.mariaandreu.shoplist;

/**
 * Created by mariaandreu on 10/1/18.
 */

public interface TestInterface {
    public void onClicked(int position, boolean status);
}
