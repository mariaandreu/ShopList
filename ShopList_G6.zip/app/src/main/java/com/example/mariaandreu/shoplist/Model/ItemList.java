package com.example.mariaandreu.shoplist.Model;

import android.widget.CheckBox;

/**
 * Created by mariaandreu on 20/12/17.
 */

public class ItemList {
    private String name;
    private int cantidad;
    private boolean isSelected;

    public ItemList(String name, int cantidad) {
        this.name = name;
        this.cantidad = cantidad;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

}



